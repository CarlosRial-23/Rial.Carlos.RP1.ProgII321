package rialcarlosrp1progii321;

public interface Vacunable {
    public void vacunar();
}
