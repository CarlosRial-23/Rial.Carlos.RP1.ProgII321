package rialcarlosrp1progii321;

public class Reptil extends Animal{

    private String tipoEScama;
    private String regTemperatura;

    public Reptil(String nombre, int edad,String tipoEScama, String regTemperatura) {
        super(nombre, edad);
        this.tipoEScama = tipoEScama;
        this.regTemperatura = regTemperatura;
    }

    @Override
    public String toString() {
        return "Reptil[" + "tipoEScama=" + tipoEScama + ", regTemperatura=" + regTemperatura + ']';
    }
    
    

    
    
    
    
    

}
