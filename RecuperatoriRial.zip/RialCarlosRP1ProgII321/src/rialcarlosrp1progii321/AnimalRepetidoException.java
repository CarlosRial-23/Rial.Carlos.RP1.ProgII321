package rialcarlosrp1progii321;

public class AnimalRepetidoException extends RuntimeException{

    private static final String MESSAGE = "Este animal ya existe";
    
    public AnimalRepetidoException() {
        super(MESSAGE);
    }
}
