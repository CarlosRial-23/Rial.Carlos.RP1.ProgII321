package rialcarlosrp1progii321;

public enum Dieta {
    HERBIVORO, CARNIVORO, OMNIVORO;
}
