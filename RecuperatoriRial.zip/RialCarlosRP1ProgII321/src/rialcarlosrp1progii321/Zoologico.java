package rialcarlosrp1progii321;

import java.util.ArrayList;
import java.util.List;

public class Zoologico {

    private List<Animal> animales;

    public Zoologico() {
        animales = new ArrayList<>();
    }
    
    public void agregarAnimal(Animal a){
        
        if(animales.contains(a)){
            throw new AnimalRepetidoException();
        }
        animales.add(a);
        
    }
    
    public void vacunarAnimales(){
        for (Animal a: animales){
            if(a instanceof Vacunable vacu ){
                vacu.vacunar();
            }else{
                System.out.println(a.getNombre() + ", soy un reptil no pueden me vacunar");
            }
            
            
        }
    }
    
    public void mostrarAnimales(){
        
        for (Animal a: animales){
            System.out.println(a);
        }
        
    }

}
