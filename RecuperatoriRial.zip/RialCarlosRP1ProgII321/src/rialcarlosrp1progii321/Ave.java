package rialcarlosrp1progii321;

public class Ave extends Animal implements Vacunable{

    private double envergaduraAlas;

    public Ave(String nombre, int edad, double envergaduraAlas) {
        super(nombre, edad);
        this.envergaduraAlas = envergaduraAlas;
    }

    @Override
    public void vacunar() {
        System.out.println(getNombre()+" y soy Ave. Pueden vacunarme");
    }

    @Override
    public String toString() {
        return "Ave[" + "envergaduraAlas=" + envergaduraAlas + ']';
    }
    
    
            
            

}
