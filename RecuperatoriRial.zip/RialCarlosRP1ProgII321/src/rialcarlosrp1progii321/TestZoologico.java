package rialcarlosrp1progii321;

public class TestZoologico {

    public static void main(String[] args) {
        
        Zoologico zoo1 = new Zoologico();
        cargarDatos(zoo1);
        zoo1.mostrarAnimales();
        zoo1.vacunarAnimales();

    }

    public static void cargarDatos(Zoologico zoo){
        Reptil rep1 = new Reptil("Iguana-A", 4, "queratinosa", "ecotermia");
        Reptil rep2 = new Reptil("Iguana-2", 3, "queratinosa", "ecotermia");
        Mamifero mami1 = new Mamifero("Leon", 2, 12.5, Dieta.CARNIVORO);
        Mamifero mami2 = new Mamifero("Cebra", 6, 18.5, Dieta.OMNIVORO);
        Ave ave1 = new Ave("paloma", 5, 54.7);
        try {
            zoo.agregarAnimal(rep1);
            zoo.agregarAnimal(rep2);
            zoo.agregarAnimal(mami1);
            zoo.agregarAnimal(mami2);
            zoo.agregarAnimal(ave1);
            zoo.agregarAnimal(rep1);
            
            
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
    }
    
}
