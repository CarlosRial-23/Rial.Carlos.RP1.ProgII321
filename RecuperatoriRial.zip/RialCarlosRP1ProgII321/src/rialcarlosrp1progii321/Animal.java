package rialcarlosrp1progii321;

import java.util.Objects;

public abstract class Animal {

    private String nombre;
    private int edad;
    

    public Animal(String nombre, int edad) {
        this.nombre = nombre;
        this.edad = edad;
    }
    
    public String getNombre() {
        return nombre;
    }
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || !(obj instanceof Animal)) {
            return false;
        }
        
        final Animal other = (Animal) obj;
        return nombre.equals(other.nombre) && edad == other.edad;
    }
    
    
    
    @Override
    public int hashCode(){
       return Objects.hash(nombre,edad);
    }

    
    
    
    
}
